# SarcoSense – Muscle Health Check (Prototype)

A 2-minute, explainable muscle-health check for adults 40+. Built for the Hack for Social Cause hackathon.

## What it does
- Takes 5 quick inputs: age/weight/protein, a 30-second chair-stand count, and the 5 SARC-F questions
- Gives a 0–100 risk-point score with a "why this score" breakdown
- Suggests a daily protein target and a starter exercise plan

## Run it
Open `index.html` in any browser. No install, no server, no data stored.

## How scoring works (rule-based, no ML)
SARC-F (up to 50) + chair-stand vs reference (up to 25) + age (up to 15) + protein per kg (up to 10).
Bands: under 25 lower, 25–49 moderate, 50+ higher.

## Disclaimer
Wellness and education only. Not a diagnosis or medical advice.

## Roadmap
Full architecture (Flutter, FastAPI, PostgreSQL, AI Coach) is planned in the project roadmap.

## References
EWGSOP2 (Cruz-Jentoft 2019); SARC-F (Malmstrom & Morley 2013); PROT-AGE (Bauer 2013); CDC STEADI chair stand.
